﻿namespace IGse.ViewModels
{
    public class SetPriceVm
    {
        public decimal ElectricityPriceNight { get; set; }
        public decimal ElectricityPriceDay { get; set; }
        public decimal GasPrice { get; set; }
        public decimal StandingCharge { get; set; }
    }
}
