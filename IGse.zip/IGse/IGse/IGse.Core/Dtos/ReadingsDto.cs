﻿namespace IGse.Core.Dtos;
public class ReadingsDto
{
    public int ElectricityDayReading { get; set; }
    public int ElectricityNightReading { get; set; }
    public int GasReading { get; set; }
}
