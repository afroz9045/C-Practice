﻿using System;
using System.Collections.Generic;

namespace JWT.Authentication.Core.Entities
{
    public class Designation
    {
        public string DesignationId { get; set; } = null!;
        public string DesignationName { get; set; } = null!;
    }
}