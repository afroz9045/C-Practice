﻿namespace JWT.Authentication.server.Infrastructure.Vm
{
    public class RegistrationVm
    {
        
        public int CustomerId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}