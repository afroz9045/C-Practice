﻿namespace JWT.Authentication.Server.Infrastructure.VM
{
    public class LoginVm
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
